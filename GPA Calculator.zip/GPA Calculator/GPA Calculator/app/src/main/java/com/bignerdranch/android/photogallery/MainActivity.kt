package com.bignerdranch.android.photogallery

import android.annotation.SuppressLint
import android.app.PendingIntent.getActivity
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.StrictMode
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputEditText
import kotlinx.android.synthetic.main.activity_main.*
import java.io.*
import java.lang.Double.parseDouble
import java.net.HttpURLConnection
import java.net.URL


var totalCreds = 0.0
var lastCalcedCreds = 0.0

class MainActivity : AppCompatActivity() {
    //Defining various items in each course field
    private lateinit var courseOneGrade: TextInputEditText
    private lateinit var courseTwoGrade: TextInputEditText
    private lateinit var courseThreeGrade: TextInputEditText
    private lateinit var courseFourGrade: TextInputEditText
    private lateinit var courseFiveGrade: TextInputEditText
    private lateinit var courseSixGrade: TextInputEditText
    private lateinit var courseOneCredits: TextInputEditText
    private lateinit var courseTwoCredits: TextInputEditText
    private lateinit var courseThreeCredits: TextInputEditText
    private lateinit var courseFourCredits: TextInputEditText
    private lateinit var courseFiveCredits: TextInputEditText
    private lateinit var courseSixCredits: TextInputEditText
    private lateinit var profileButton: ImageButton

    //Function that causes the profile picture to be set after picking it in the image search
    override fun onResume() {
        super.onResume()
        try {
            setProfilePic()
        }
        catch (e: IOException) {
        }
    }

    //Function that intitializes everything in the main activity
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Lines that allow for the setting of an image based on url
        val policy = StrictMode.ThreadPolicy.Builder().permitAll().build()
        StrictMode.setThreadPolicy(policy)

        //Initializing various items in each course field as well as declaring variables
        var numAddedCourses = 0
        var courseJustRemoved = false
        var courseJustAdded = false
        val addCourseButton = findViewById(R.id.addCourseBtn) as Button
        val calcGPAButton = findViewById(R.id.calcGpaBtn) as Button
        val remCourseButton = findViewById(R.id.remCourseBtn) as Button
        val saveSemButton = findViewById(R.id.saveSemBtn) as Button
        val courseFiveText = findViewById(R.id.c5TV) as TextView
        val courseSixText = findViewById(R.id.c6TV) as TextView
        val GPAText = findViewById(R.id.gpaTV) as TextView
        val viewPastSemButton = findViewById(R.id.viewPastSemBtn) as Button
        profileButton = findViewById(R.id.profileImageButton) as ImageButton
        courseOneGrade = findViewById(R.id.c1Grade) as TextInputEditText
        courseOneCredits = findViewById(R.id.c1Credits) as TextInputEditText
        courseTwoGrade = findViewById(R.id.c2Grade) as TextInputEditText
        courseTwoCredits = findViewById(R.id.c2Credits) as TextInputEditText
        courseThreeGrade = findViewById(R.id.c3Grade) as TextInputEditText
        courseThreeCredits = findViewById(R.id.c3Credits) as TextInputEditText
        courseFourGrade = findViewById(R.id.c4Grade) as TextInputEditText
        courseFourCredits = findViewById(R.id.c4Credits) as TextInputEditText
        courseFiveGrade = findViewById(R.id.c5Grade) as TextInputEditText
        courseFiveCredits = findViewById(R.id.c5Credits) as TextInputEditText
        courseSixGrade = findViewById(R.id.c6Grade) as TextInputEditText
        courseSixCredits = findViewById(R.id.c6Credits) as TextInputEditText

        //Defining the actionbar
        val actionbar = supportActionBar
        actionbar!!.title = "GPA Calculator"
        saveSemButton.isEnabled = false
        remCourseButton.isEnabled = false
        //Setting the profile picture when the app starts
        try {
            setProfilePic()
        }
        catch (e: IOException) {
        }

        //////////////////////////////////////ON TEXT CHANGED LISTENERS BELOW//////////////////////////////////////
        //All of the below functions reset the save semester button when the text boxes are changed
        c1Credits!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c2Credits!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c3Credits!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c4Credits!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c5Credits!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c6Credits!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c1Grade!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c2Grade!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c3Grade!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c4Grade!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c5Grade!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})
        c6Grade!!.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(p0: Editable?) {
                saveSemButton.isEnabled = false
            }
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
                Log.d("Text not changed", "Text not changed")
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                saveSemButton.isEnabled = false
            }})

        //////////////////////////////////////ON CLICK LISTENERS BELOW//////////////////////////////////////
        //Function that sends the user to the profile picture search after clicking the profile picture iron
        profileButton.setOnClickListener{
            startActivity(Intent(this@MainActivity,PhotoGalleryActivity::class.java))
        }

        //Button Click Listener That Adds Courses
        addCourseButton.setOnClickListener{
            if(courseJustRemoved == true){
                numAddedCourses = 1
            }
            if(numAddedCourses == 0){
                courseFiveText.visibility = View.VISIBLE
                courseFiveGrade.visibility = View.VISIBLE
                courseFiveCredits.visibility = View.VISIBLE
                remCourseButton.isEnabled = true
                numAddedCourses ++
                courseJustAdded = true
            }
            else if(numAddedCourses == 1){
                courseSixText.visibility = View.VISIBLE
                courseSixGrade.visibility = View.VISIBLE
                courseSixCredits.visibility = View.VISIBLE
                addCourseButton.isEnabled = false
                courseJustAdded = false
            }
        }
        //Button Click Listener That Removes Courses
        remCourseButton.setOnClickListener{
            if(courseJustAdded == true){
                numAddedCourses = 0
            }
            if(numAddedCourses == 0){
                courseFiveText.visibility = View.INVISIBLE
                courseFiveGrade.visibility = View.INVISIBLE
                courseFiveCredits.visibility = View.INVISIBLE
                remCourseButton.isEnabled = false
                courseJustRemoved = false
            }
            else if(numAddedCourses == 1){
                courseSixText.visibility = View.INVISIBLE
                courseSixGrade.visibility = View.INVISIBLE
                courseSixCredits.visibility = View.INVISIBLE
                addCourseButton.isEnabled = true
                numAddedCourses --
                courseJustRemoved = true
            }
        }

        //Button Click Listener That Saves Semester Data Locally to gradesFile
        saveSemButton.setOnClickListener(){
            if(GPAText.text.toString().length > 10){
                GPAText.text = GPAText.text.toString().substring(0, 10)
            }
            var fileName = "gradesFile"
            var fileData = "Semester Credits: " + lastCalcedCreds.toString() + " " + GPAText.text.toString() + System.lineSeparator()

            val fileOutputStream: FileOutputStream
            try {
                fileOutputStream = openFileOutput(fileName, Context.MODE_APPEND)
                fileOutputStream.write(fileData.toByteArray())
            }catch (e: Exception){
                e.printStackTrace()
            }

            saveSemButton.isEnabled = false
            totalCreds = 0.0
        }

        //Button Click Listener To Calculate The GPA
        calcGPAButton.setOnClickListener(){
            try{
                GPAText.text = "GPA: " + getGPA().toString()
            }catch(e: IOException){ }

            lastCalcedCreds = totalCreds
            totalCreds = 0.0
            if(GPAText.text.toString().length > 10){
                GPAText.text = GPAText.text.toString().substring(0, 10)
            }
            if(GPAText.text.toString() != "GPA: NaN"){
                saveSemButton.isEnabled = true
            }
            else if(GPAText.text.toString() == "GPA: NaN"){
                GPAText.text = "GPA: 0.000"
            }
        }

        //Button Click Listener To Change Activity to PastSemActivity and display all past semester data
        viewPastSemButton.setOnClickListener(){
                startActivity(Intent(this@MainActivity, PastSemActivity::class.java))
        }
    }

    //////////////////////////////////////VARIOUS CLASS FUNCTIONS BELOW//////////////////////////////////////
    //Function to get a drawable image from a passed URL string
    @Throws(IOException::class)
    fun drawableFromUrl(url: String?): Drawable? {
        val x: Bitmap
        val connection =
            URL(url).openConnection() as HttpURLConnection
        connection.connect()
        val input = connection.inputStream
        x = BitmapFactory.decodeStream(input)
        return BitmapDrawable(Resources.getSystem(), x)
    }

    //Function that reads from the picUrlFile to get the profile Url as a string
    //It then calls drawableFromUrl to get a drawable image and sets the profile picture
    //to that image
    fun setProfilePic(){
        var fileInputStream: FileInputStream? = null
        fileInputStream = openFileInput("picUrlFile")
        var inputStreamReader = InputStreamReader(fileInputStream)
        val bufferedReader = BufferedReader(inputStreamReader)
        val stringBuilder: StringBuilder = StringBuilder()
        var text: String? = null
        while ({ text = bufferedReader.readLine() ; text}() != null)
        {
            stringBuilder.append(text)
        }

        profileButton.setImageDrawable(drawableFromUrl(stringBuilder.toString()))
    }

    //Function to calculate a weighted gpa based on the values in each textField
    fun getGPA(): Double {
        var c1GradePoints = 0.0
        var c2GradePoints = 0.0
        var c3GradePoints = 0.0
        var c4GradePoints = 0.0
        var c5GradePoints = 0.0
        var c6GradePoints = 0.0

        var totalGradePoints = 0.0
        val c1g: String = courseOneGrade.text.toString()
        val c2g: String = courseTwoGrade.text.toString()
        val c3g: String = courseThreeGrade.text.toString()
        val c4g: String = courseFourGrade.text.toString()
        val c5g: String = courseFiveGrade.text.toString()
        val c6g: String = courseSixGrade.text.toString()
        val c1c: String = courseOneCredits.text.toString()
        val c2c: String = courseTwoCredits.text.toString()
        val c3c: String = courseThreeCredits.text.toString()
        val c4c: String = courseFourCredits.text.toString()
        val c5c: String = courseFiveCredits.text.toString()
        val c6c: String = courseSixCredits.text.toString()

        if(c1c.trim().length > 0 && c1g.trim().length > 0 && isDouble(c1c)){
            c1GradePoints = c1c.toDouble() * gradeToNum(c1g)
            totalGradePoints += c1GradePoints
            totalCreds += c1c.toDouble()
        } else{
            Toast.makeText(this, "Ensure that your grade is: A +/-, B +/-, C +/-, D +/-, or F +/-. " +
                    "\n Also ensure that your credits are a number.", Toast.LENGTH_LONG).show()
        }
        if(c2c.trim().length > 0 && c2g.trim().length > 0 && isDouble(c2c)){
            c2GradePoints = c2c.toDouble() * gradeToNum(c2g)
            totalGradePoints += c2GradePoints
            totalCreds += c2c.toDouble()
        } else{
            Toast.makeText(this, "Ensure that your grade is: A +/-, B +/-, C +/-, D +/-, or F +/-. " +
                    "\n Also ensure that your credits are a number.", Toast.LENGTH_LONG).show()
        }
        if(c3c.trim().length > 0 && c3g.trim().length > 0 && isDouble(c3c)){
            c3GradePoints = c3c.toDouble() * gradeToNum(c3g)
            totalGradePoints += c3GradePoints
            totalCreds += c3c.toDouble()
        } else{
            Toast.makeText(this, "Ensure that your grade is: A +/-, B +/-, C +/-, D +/-, or F +/-. " +
                    "\n Also ensure that your credits are a number.", Toast.LENGTH_LONG).show()
        }
        if(c4c.trim().length > 0 && c4g.trim().length > 0 && isDouble(c4c)){
            c4GradePoints = c4c.toDouble() * gradeToNum(c4g)
            totalGradePoints += c4GradePoints
            totalCreds += c4c.toDouble()
        } else{
            Toast.makeText(this, "Ensure that your grade is: A +/-, B +/-, C +/-, D +/-, or F +/-. " +
                    "\n Also ensure that your credits are a number.", Toast.LENGTH_LONG).show()
        }
        if(c5c.trim().length > 0 && c5g.trim().length > 0 && isDouble(c5c)){
            c5GradePoints = c5c.toDouble() * gradeToNum(c5g)
            totalGradePoints += c5GradePoints
            totalCreds += c5c.toDouble()
        }else{
            Toast.makeText(this, "Ensure that your grade is: A +/-, B +/-, C +/-, D +/-, or F +/-. " +
                    "\n Also ensure that your credits are a number.", Toast.LENGTH_LONG).show()
        }
        if(c6c.trim().length > 0 && c6g.trim().length > 0 && isDouble(c6c)){
            c6GradePoints = c6c.toDouble() * gradeToNum(c6g)
            totalGradePoints += c6GradePoints
            totalCreds += c6c.toDouble()
        }else{
            Toast.makeText(this, "Ensure that your grade is: A +/-, B +/-, C +/-, D +/-, or F +/-. " +
                    "\n Also ensure that your credits are a number.", Toast.LENGTH_LONG).show()
        }

        return totalGradePoints / totalCreds
    }

    //function that tests if credits are a number
    fun isDouble(passedCredits: String): Boolean{
        var numeric = true
        try {
            var num = parseDouble(passedCredits)
        } catch (e: NumberFormatException) {
            numeric = false
        }
        return numeric
    }
    //Function to convert each string grade to a double number which reflects that grade
    fun gradeToNum(passedGrade: String): Double {
        if(passedGrade == "A+" || passedGrade == "a+" || passedGrade == "A" || passedGrade == "a"){ return 4.0 }
        if(passedGrade == "A-" || passedGrade == "a-"){ return 3.7 }
        if(passedGrade == "B+" || passedGrade == "b+"){ return 3.3 }
        if(passedGrade == "B" || passedGrade == "b"){ return 3.0 }
        if(passedGrade == "B-" || passedGrade == "b-"){ return 2.7 }
        if(passedGrade == "C+" || passedGrade == "c+"){ return 2.3 }
        if(passedGrade == "C" || passedGrade == "c"){ return 2.0 }
        if(passedGrade == "C-" || passedGrade == "c-"){ return 1.7 }
        if(passedGrade == "D+" || passedGrade == "d+"){ return 1.3 }
        if(passedGrade == "D" || passedGrade == "d"){ return 1.0 }
        if(passedGrade == "D-" || passedGrade == "d-"){ return 0.7 }
        if(passedGrade == "F" || passedGrade == "f"){ return 0.0 }
        return 0.0
    }
}