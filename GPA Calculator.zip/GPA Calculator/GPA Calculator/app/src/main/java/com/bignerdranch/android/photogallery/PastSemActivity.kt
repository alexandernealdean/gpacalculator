package com.bignerdranch.android.photogallery

import android.os.Bundle
import android.text.method.ScrollingMovementMethod
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_past_sem.*
import java.io.BufferedReader
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStreamReader


//Class that loads and displays the data from saved semesters
class PastSemActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_past_sem)

        val actionbar = supportActionBar
        actionbar!!.title = "Past Semesters"
        actionbar.setDisplayHomeAsUpEnabled(true)
        actionbar.setDisplayHomeAsUpEnabled(true)

        //Reading data from gradesFile to display to the textview on activity_past_sem.xml
        try {
            var fileInputStream: FileInputStream? = null
            fileInputStream = openFileInput("gradesFile")
            var inputStreamReader = InputStreamReader(fileInputStream)
            val bufferedReader = BufferedReader(inputStreamReader)
            val stringBuilder: StringBuilder = StringBuilder()
            var text: String? = null
            while ({ text = bufferedReader.readLine(); text }() != null) {
                stringBuilder.append(text + "\n\n")
            }
            //Setting the textview text to the data from the file and allowing for scrolling
            pastSemData.text = stringBuilder.toString()
            pastSemData.setMovementMethod(ScrollingMovementMethod())
        }catch(e: IOException){}

    }


    override fun onSupportNavigateUp(): Boolean {
        onBackPressed()
        return true
    }
}